﻿#Install-module DellBIOSProvider
#Import-module DellBIOSProvider


import-module "$PSScriptRoot\dellbiosprovider.2.7.0\DellBIOSProvider.PSd1" -Force -Scope Local


$Output = New-Object System.Collections.ArrayList
$SettingsList = (Get-ChildItem DellSmBIOS:\).category
$i = 1

$t = $SettingsList.count

foreach ($Unit in $SettingsList)
{
    Write-Progress -Activity "$i/$t - Working on $unit category" -Id 10 -PercentComplete $(($i++/$t)*100)
    $BIOSSettings = Get-ChildItem -Path ("DellSmBIOS:\" + $Unit) -WarningVariable +BIOS_Warning -WarningAction SilentlyContinue

    $j = 1
    foreach ($Junit in $BIOSSettings)
    {
        Write-Progress -Activity "Getting the $($Junit.Attribute) Attribute info" -ParentId 10 -PercentComplete $(($j++/$t)*100)
        $objProp = @{
                'Category' = $unit;
                'Attribute' = $Junit.Attribute;
                'CurrentValue' = $Junit.CurrentValue;
                'ShortDescription' = $Junit.ShortDescription
            }
        $Obj = New-Object PSCustomObject -Property $objProp
        $Output.Add($obj) | Out-Null

        Clear-Variable JUNIT,objProp,Obj
    }


}

"`n########## Output ##########`n"
$Output | Select-Object Category,Attribute,CurrentValue,ShortDescription
"`n########## Warnings ##########`n"
$BIOS_Warning

$JSONOutput = $output | ConvertTo-Json
$JSONOutput | out-file "$PSScriptRoot\BIOSSettings.json"
$Output | Export-Csv -Path "$PSScriptRoot\BiosSettings.csv" -NoClobber -NoTypeInformation -Force -Confirm:$false
$BIOS_Warning | Out-File "$PSScriptRoot\BIOS_Warnings.txt" 
